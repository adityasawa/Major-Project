$(document).ready(function () {
  //hide and show profession/artform
  $('input[name="role"]').click(function () {
    var test = $(this).val();
    if (test === "Artist") {
      $("#profession,#L_profession").css("display", "none");
      $("#artform,#L_artform").css("display", "block");
    }
    if (test === "User") {
      $("#artform,#L_artform").css("display", "none");
      $("#profession,#L_profession").css("display", "block");
    }
  });
  //validate User Type
  function validateUserType() {
    if ($('input[name="role"]:checked').length != 0) {
      return true;
    } else {
      alert("please select User Type");
      return false;
    }
  }

  //validate Name
  function validateName() {
    if (
      ($("#name").val().length < 5 && $("#name").val().length > 50) ||
      $.trim($("#name").val()) == ""
    ) {
      alert("please enter valid Name");
      return false;
    } else {
      return true;
    }
  }

  //validate Email
  function validateEmail() {
    var pattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
    var email = $("#email").val();

    //validate if email already exits

    if (pattern.test(email)) {
      // if ($('input[name="role"]:checked').val() === "Artist") {
      //   $.get("http://localhost:3000/Artist", function (data, status) {
      //     for (var i = 0; i < data.length; i++) {
      //       if (data[i].Email !== email) {
      //         return true;
      //       }
      //     }
      //   });
      // } else {
      //   $.get("http://localhost:3000/User", function (data, status) {
      //     for (var i = 0; i < data.length; i++) {
      //       if (data[i].Email !== email) {
      //         return true;
      //       }
      //     }
      //   });
      // }
      return true;
    } else {
      alert("Invalid Email Pattern!!");
      return false;
    }

    //check for duplicate email 2nd method
    // if ($('input[name="role"]:checked').val() === "Artist") {
    //   $.getJSON("http://localhost:3000/Artist", function (data) {
    //     $.each(data, function (key, value) {
    //       if (value.Email === email) {
    //         alert("Email already Registred");
    //         $("#form2").submit();
    //         return false;
    //       }
    //     });
    //   });
    // } else {
    //   $.getJSON("http://localhost:3000/User", function (data) {
    //     $.each(data, function (key, value) {
    //       if (value.Email === email) {
    //         alert("Email already Registred");
    //         $("#form2").submit();
    //         return false;
    //       }
    //     });
    //   });
    // }
  }

  //validate ArtForm
  function validateArtForm() {
    if ($('input[name="role"]:checked').val() === "User") {
      return true;
    }
    let artForm = $("#artform").val();
    if (artForm.length === 0) {
      alert("please select valid Art Form!!");
      return false;
    } else {
      return true;
    }
  }

  //validate Profession
  function validateProfession() {
    if ($('input[name="role"]:checked').val() === "Artist") {
      return true;
    }
    if (
      ($("#profession").val().length < 3 &&
        $("#profession").val().length > 50) ||
      $.trim($("#profession").val()) == ""
    ) {
      alert("please enter valid Profession");
      return false;
    } else {
      return true;
    }
  }

  //validate Contact
  function validateContact() {
    let num = /^\d{10}$/;
    let ipNum = $("#contact_no").val();
    if (num.test(ipNum)) {
      return true;
    } else {
      alert("please enter valid Contact Number");
      return false;
    }
  }

  //validate Gender
  function validateGender() {
    if ($('input[name="gender"]:checked').length != 0) {
      return true;
    } else {
      alert("please select Gender");
      return false;
    }
  }

  //validate Address
  function validateAddress() {
    if (
      ($("#address").val().length < 3 && $("#address").val().length > 50) ||
      $.trim($("#address").val()) == ""
    ) {
      alert("please enter valid Address");
      return false;
    } else {
      return true;
    }
  }

  //validate Password
  function validatePassword() {
    if (
      ($("#password").val().length < 3 && $("#password").val().length > 50) ||
      $.trim($("#password").val()) == ""
    ) {
      alert("please enter valid Password");
      return false;
    } else {
      return true;
    }
  }

  //validate CPassword
  function validateCPassword() {
    if ($("#Cpassword").val() != $("#password").val()) {
      alert("please enter valid Password in Confirm Password");
      return false;
    } else {
      return true;
    }
  }

  //validate Upload Photo profile_pic
  function validateUploadPhoto() {
    if ($("#profile_pic").val() === "") {
      alert("please select photo");
      return false;
    } else {
      return true;
    }
  }

  $("#submit").click(function (e) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    if (
      validateUserType() &&
      validateName() &&
      validateEmail() &&
      (validateArtForm() || validateProfession()) &&
      validateContact() &&
      validateGender() &&
      validateAddress() &&
      validatePassword() &&
      validateCPassword() &&
      validateUploadPhoto()
    ) {
      if ($('input[name="role"]:checked').val() === "Artist") {
        $.post("http://localhost:3000/Artist", {
          Role: $('input[name="role"]:checked').val(),
          Name: $("#name").val(),
          Email: $("#email").val(),
          Art_Form: $("#artform").val(),
          Contact_No: $("#contact_no").val(),
          Gender: $('input[name="gender"]:checked').val(),
          Address: $("#address").val(),
          Password: $("#password").val(),
          C_Password: $("#Cpassword").val(),
          Profile_Pic: $("#profile_pic").val(), //actualPath//imgPath
        });
      } else {
        $.post("http://localhost:3000/User", {
          Role: $('input[name="role"]:checked').val(),
          Name: $("#name").val(),
          Email: $("#email").val(),
          Profession: $("#profession").val(),
          Contact_No: $("#contact_no").val(),
          Gender: $('input[name="gender"]:checked').val(),
          Address: $("#address").val(),
          Password: $("#password").val(),
          C_Password: $("#Cpassword").val(),
          Profile_Pic: $("#profile_pic").val(), //actualPath//imgPath
        });
      }
    } else {
      alert("Something Went Wrong...Please Try Again later");
    }
  });

  // $("#b2").click(function() {
  //     location.href =  "index.html";
  // });
  // , "http://localhost:3000/User", {
  //         Profile_Pic: img,
  //     }
});
